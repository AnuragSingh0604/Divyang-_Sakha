package com.example.divyangshakha;

public class disabilityModel {
    int img;
    String disability;
    public disabilityModel(int img,String  disability )
    {
        this. disability= disability;
        this.img=img;

    }
}
